SOURCE_DIR='/d/cloud'
BACKUP_DIR='/d/backup'
TIMESTAMP=$(date +%Y-%m-%d_%H-%M-%S)
BACKUP_FILE="backup-$TIMESTAMP.tar.gz"