$name=read-host "Enter your  name"
write-host "Hello $name"

$names=@("John","Doe","Jane")
$nae