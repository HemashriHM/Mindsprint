echo "Hello"
name="Hemashri"
salary=1000
echo "My name is $name"
echo "salary $((salary*90))"
num1=90
num2=78
echo "Addition of $num1 and $num2 is $((num1+num2))"
echo "Subtraction of $num1 and $num2 is $((num1-num2))"
echo "Multiplication of $num1 and $num2 is $((num1*num2))"  
