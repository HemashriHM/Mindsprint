numbers=(1 2 3 4 5 6 7 8 9 10)

echo "First element: ${numbers[0]}"
echo "Fourth element: ${numbers[3]}"
names=("alex" "john" "james")

echo "First name: ${names[0]}"